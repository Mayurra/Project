﻿using System.ComponentModel.DataAnnotations;

namespace LoginPanel.Models
{
    public class Users
    {
        [Key]
        public int UserId { get; set; }
        public string? Username { get; set; }

        [Required(ErrorMessage = "Required")]
        public string Email { get; set; }
        public string? Phone { get; set; }

        [Required(ErrorMessage = "Required")]
        public string Password { get; set; }
        public bool IsAdmin { get; set; }
    }

}
