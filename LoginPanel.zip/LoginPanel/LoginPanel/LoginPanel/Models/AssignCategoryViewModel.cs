﻿namespace LoginPanel.Models
{
    public class AssignCategoryViewModel
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
        public List<CategoryViewModel> Categories { get; set; }
    }

    public class CategoryViewModel
    {
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
        public bool IsAssigned { get; set; } 
    }

}
