﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LoginPanel.Models
{
    public class Category
    {
        [Key]
        public int Id { get; set; }
        [Required(ErrorMessage = "Required")]
        public string Name { get; set; }
    }

    public class SubCategory
    {
        [Key]
        public int Id { get; set; }
        [Required(ErrorMessage = "Required")]
        public string Name { get; set; }
        public int CategoryId { get; set; }
        public Category Category { get; set; }  
    }

    public class UserCategory
    {
        [Key]
        public int id { get; set; }
        public int UserId { get; set; }
        public int CategoryId { get; set; }

        public Category Category { get; set; }
    }
}
