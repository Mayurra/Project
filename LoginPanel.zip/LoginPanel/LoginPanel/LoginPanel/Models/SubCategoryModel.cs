﻿using Microsoft.AspNetCore.Mvc.Rendering;

namespace LoginPanel.Models
{
    public class SubCategoryModel
    {
        public SubCategory? SubCategory { get; set; }
        public List<SelectListItem>? loCategories { get; set; }
    }
}
