﻿using LoginPanel.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LoginPanel.Controllers
{
    public class UserController : Controller
    {
        private readonly ApplicationDbContext _context;

        public UserController(ApplicationDbContext context)
        {
            _context = context;
        }

        public ActionResult Index()
        {
            if (HttpContext.Session.GetString("UserRole") != "User")
            {
                return RedirectToAction("Index", "Login");
            }

            var userId = HttpContext.Session.GetInt32("UserId");
            List<UserCategory> loUserCategory = new List<UserCategory>();
            if (userId != null && userId != 0)
            {
                loUserCategory = _context.UserCategory
                                     .Where(x => x.UserId == userId)
                                    .Include(s => s.Category).ToList();
            }
            return View("~/Views/User/Index.cshtml", loUserCategory);
        }

        public ActionResult ViewSubCategories(int categoryId)
        {
            List<SubCategory> loSubCategory = new List<SubCategory>();
            if(categoryId != 0)
                loSubCategory = _context.SubCategory.Where(x => x.CategoryId == categoryId).ToList();

            return View(loSubCategory);
        }
    }
}
