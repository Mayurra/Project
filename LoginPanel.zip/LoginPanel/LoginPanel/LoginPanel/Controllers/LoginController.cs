﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

public class LoginController : Controller
{
    private readonly ApplicationDbContext _context;

    public LoginController(ApplicationDbContext context)
    {
        _context = context;
    }

    public ActionResult Index()
    {
        return View();
    }

    [HttpPost]
    public async Task<ActionResult> Index(string email, string password)
    {
        var user = await _context.Users
           .FirstOrDefaultAsync(u => u.Email == email && u.Password == password);

        if (user != null)
        {
            HttpContext.Session.SetInt32("UserId", user.UserId);
            HttpContext.Session.SetString("UserName", user.Username);
            HttpContext.Session.SetString("UserRole", user.IsAdmin ? "Admin" : "User");


            if (user.IsAdmin)
            {
                return RedirectToAction("Index", "Admin");
            }
            else
            {
                return RedirectToAction("Index", "User");
            }
        }
        ViewBag.Message = "Invalid credentials";
        return View();


        //string lsError = "";
        //if (string.IsNullOrEmpty(email))
        //    lsError = "Please Enter Email";
        //else if (string.IsNullOrEmpty(password))
        //    lsError = "Please Enter password";
        //else { 
        //    var user = await _context.Users
        //    .FirstOrDefaultAsync(u => u.Email == email && u.Password == password);

        //    if (user != null)
        //    {
        //        if (user.IsAdmin)
        //        {
        //            return RedirectToAction("Index", "Admin");
        //        }
        //        else
        //        {
        //            return RedirectToAction("Index", "User");
        //        }
        //    }
        //    lsError = "Invalid credentials";
        //}
        //ViewBag.Message = lsError; 
        //return View();
    }

    public ActionResult Logout()
    {
        HttpContext.Session.Clear();
        return RedirectToAction("Index");
    }
}
