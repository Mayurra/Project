﻿using LoginPanel.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace LoginPanel.Controllers
{
    public class AdminController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AdminController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            if (HttpContext.Session.GetString("UserRole") != "Admin")
            {
                return RedirectToAction("Index", "Login");
            }
            return View();
        }

        public ActionResult ManageCategories(string stAnything)
        {
            List<Category> loCategories = new List<Category>();

            if (stAnything == "0")
                loCategories = _context.Category.ToList();
            else
            {
                Category? loCategory = _context.Category.Find(Convert.ToInt32(stAnything));
                return View("~/Views/Admin/AddCategory.cshtml", loCategory);
            }
            return View("~/Views/Admin/CategoriesList.cshtml", loCategories);
        }

        public IActionResult SaveCategory(Category loCategories)
        {
            if (!string.IsNullOrEmpty(loCategories.Name))
            {
                if (loCategories.Id != 0)
                {
                    var loCategory = _context.Category.Find(loCategories.Id);
                    if (loCategory != null)
                    {
                        loCategory.Name = loCategories.Name;
                        _context.SaveChanges();
                    }
                }
                else
                {
                    _context.Category.Add(loCategories);
                    _context.SaveChanges();
                }
            }
            return RedirectToAction("ManageCategories", new { stAnything = "0" });
        }

        public IActionResult DeleteCategory(int id)
        {
            var loCategory = _context.Category.Find(id);

            if (loCategory != null)
            {
                _context.Category.Remove(loCategory);
                _context.SaveChanges();
            }
            return RedirectToAction("ManageCategories", new { stAnything = "0" });
        }
        public ActionResult ManageSubCategories(string stAnything)
        {
            List<SubCategory> loSubCategories = new List<SubCategory>();

            if (stAnything == "0")
            {
                loSubCategories = _context.SubCategory
                            .Include(s => s.Category).OrderByDescending(x => x.Id).ToList();
            }
            else
            {
                SubCategoryModel? loSubCategory = new SubCategoryModel();
                loSubCategory.SubCategory = _context.SubCategory.Find(Convert.ToInt32(stAnything));
                loSubCategory.loCategories = _context.Category.ToList()
                   .ConvertAll(a => { return new SelectListItem() { Text = a.Name, Value = a.Id.ToString() };}).OrderBy(x => x.Text).ToList();
                loSubCategory.loCategories.Insert(0, new SelectListItem() { Text = "Select", Value = "" });

                return View("~/Views/Admin/AddSubCategory.cshtml", loSubCategory);
            }
            return View("~/Views/Admin/SubCategoryList.cshtml", loSubCategories);
        }

        public IActionResult SaveSubCategory(int id, string stName, int CategoryId )
        {
            if (!string.IsNullOrEmpty(stName))
            {
                SubCategory? loSubCategory = new SubCategory();

                if (id != 0)
                {
                    loSubCategory = _context.SubCategory.Find(id);
                    if (loSubCategory != null)
                    {
                        loSubCategory.Name = stName;
                        loSubCategory.CategoryId = CategoryId;
                        _context.SaveChanges();
                    }
                }
                else
                {
                    loSubCategory.Name = stName;
                    loSubCategory.CategoryId = CategoryId;
                    _context.SubCategory.Add(loSubCategory);
                    _context.SaveChanges();
                }
            }
            return RedirectToAction("ManageSubCategories", new { stAnything = "0" });
        }
        public IActionResult DeleteSubCategory(int id)
        {
            var loSubCategory = _context.SubCategory.Find(id);

            if (loSubCategory != null)
            {
                _context.SubCategory.Remove(loSubCategory);
                _context.SaveChanges();
            }
            return RedirectToAction("ManageSubCategories", new { stAnything = "0" });
        }

        public IActionResult ManageUsers(string stAnything)
        {
            List<Users> loUsers = new List<Users>();

            if (stAnything == "0")
                loUsers = _context.Users.Where(x => x.IsAdmin == false).ToList();
            else
            {
                Users? loUser = _context.Users.Find(Convert.ToInt32(stAnything));
                return View("~/Views/Admin/AddUser.cshtml", loUser);
            }

            return View("~/Views/Admin/UserList.cshtml", loUsers);
        }

        public IActionResult SaveUser(Users loUsers)
        {
            if (!string.IsNullOrEmpty(loUsers.Email))
            {
                if (loUsers.UserId != 0)
                {
                    var loUser = _context.Users.Find(loUsers.UserId);
                    if (loUser != null)
                    {
                        loUser.Username = loUsers.Username;
                        loUser.Email = loUsers.Email;
                        loUser.Phone = loUsers.Phone;
                        loUser.Password = loUsers.Password;
                        loUser.IsAdmin = loUsers.IsAdmin;

                        _context.SaveChanges();
                    }
                }
                else
                {
                    _context.Users.Add(loUsers);
                    _context.SaveChanges();
                }

            }
            return RedirectToAction("ManageUsers", new { stAnything = "0" });
        }

        public IActionResult DeleteUser(int id)
        {
            var loUser = _context.Users.Find(id);

            if (loUser != null)
            {
                _context.Users.Remove(loUser);
                _context.SaveChanges();
            }
            return RedirectToAction("ManageUsers", new { stAnything = "0" });
        }

        public IActionResult getAssignCategories(int userId)
        {
            var user = _context.Users.Find(userId);
            if (user == null)
                return NotFound();
           
            var loCategories = _context.Category.ToList();
            var loAssignedCategories = _context.UserCategory
                                             .Where(uc => uc.UserId == userId)
                                             .Select(uc => uc.CategoryId)
                                             .ToList();

            var loAssignCategoryViewModel = new AssignCategoryViewModel
            {
                UserId = userId,
                UserName = user.Username,
                Categories = loCategories.Select(c => new CategoryViewModel
                {
                    CategoryId = c.Id,
                    CategoryName = c.Name,
                    IsAssigned = loAssignedCategories.Contains(c.Id)
                }).ToList()
            };

            return View("~/Views/Admin/AssignCategory.cshtml", loAssignCategoryViewModel);
        }

        [HttpPost]
        public IActionResult AssignCategoryToUser(AssignCategoryViewModel loAssignCategoryViewModel)
        {
            var loExistingUserCategories = _context.UserCategory
                                                 .Where(uc => uc.UserId == loAssignCategoryViewModel.UserId)
                                                 .ToList();

            _context.UserCategory.RemoveRange(loExistingUserCategories);
            _context.SaveChanges();

            var loSelectedCategories = loAssignCategoryViewModel.Categories
                                          .Where(c => c.IsAssigned)
                                          .Select(c => new UserCategory
                                          {     
                                              UserId = loAssignCategoryViewModel.UserId,
                                              CategoryId = c.CategoryId
                                          }).ToList();

            _context.UserCategory.AddRange(loSelectedCategories);
            _context.SaveChanges();

            return RedirectToAction("ManageUsers", new { stAnything = "0" });
        }
    }
}
